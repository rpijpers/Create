DROP TABLE IF EXISTS 
    `#__create_components`;